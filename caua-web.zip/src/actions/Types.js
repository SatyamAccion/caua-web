export const CREATE_EMPLOYEE = 'create_employee';
export const NETWORK_FAILED = 'Network Not Available';
export const EMPLOYEE_UPDATE = 'Employee Update';
export const CREATE_EMPLOYEE = 'Create Employee';
export const EMPLOYEE_CREATED = 'Employee Created';
export const EMPLOYEE_CREATED_FAILED = 'Employee Creation Failed';